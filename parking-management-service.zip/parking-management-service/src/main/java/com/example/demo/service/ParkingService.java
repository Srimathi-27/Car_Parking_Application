package com.example.demo.service;

import com.example.demo.model.ParkingSlot;
import com.example.demo.repository.ParkingSlotRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ParkingService {

    @Autowired
    private ParkingSlotRepository parkingSlotRepository;

    public String createSlots(int count) {
        for (int i = 1; i <= count; i++) {
            ParkingSlot slot = new ParkingSlot();
            slot.setSlotId("SLOT-" + i);
            slot.setBooked(false);
            slot.setAvailable(true);
            parkingSlotRepository.save(slot);
        }
        return count + " slots created.";
    }

    public ParkingSlot bookSlot(String slotId, String user, String vehicleNumber) {
        ParkingSlot slot = parkingSlotRepository.findBySlotId(slotId)
            .orElseThrow(() -> new RuntimeException("Slot not found"));

        if (slot.isBooked()) throw new RuntimeException("Slot already booked");

        slot.setBooked(true);
        slot.setAvailable(false);
        slot.setUser(user);
        slot.setVehicleNumber(vehicleNumber);

        return parkingSlotRepository.save(slot);
    }

    public Optional<ParkingSlot> getAvailableSlot() {
        return parkingSlotRepository.findFirstByIsAvailableTrue();
    }

    public List<ParkingSlot> getAllSlots() {
        return parkingSlotRepository.findAll();
    }
}