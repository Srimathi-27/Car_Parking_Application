package com.example.demo.repository;

import com.example.demo.model.ParkingSlot;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface ParkingSlotRepository extends JpaRepository<ParkingSlot, Long> {
    Optional<ParkingSlot> findBySlotId(String slotId);
    Optional<ParkingSlot> findFirstByIsAvailableTrue();
}
