package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "parking_slot")
public class ParkingSlot {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "slot_id", unique = true, nullable = false)
    private String slotId;

    @Column(name = "is_booked")
    private boolean booked;

    private String vehicleNumber;

    @Column(name = "is_available", nullable = false)
    private boolean isAvailable = true;

    private String user;

    // Getters and setters
    public Long getId() { return id; }

    public String getSlotId() { return slotId; }
    public void setSlotId(String slotId) { this.slotId = slotId; }

    public boolean isBooked() { return booked; }
    public void setBooked(boolean booked) {
        this.booked = booked;
        this.isAvailable = !booked;
    }

    public String getVehicleNumber() { return vehicleNumber; }
    public void setVehicleNumber(String vehicleNumber) { this.vehicleNumber = vehicleNumber; }

    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) {
        this.isAvailable = available;
        this.booked = !available;
    }

    public String getUser() { return user; }
    public void setUser(String user) { this.user = user; }
}
