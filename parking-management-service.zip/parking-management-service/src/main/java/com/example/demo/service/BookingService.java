package com.example.demo.service;

import com.example.demo.dto.BookingRequest;
import com.example.demo.model.Booking;
import com.example.demo.model.ParkingSlot;
import com.example.demo.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private ParkingService parkingService;

    public Booking bookSlot(BookingRequest request) {
        ParkingSlot slot = parkingService.bookSlot(request.getSlotId(),
                String.valueOf(request.getUserId()),
                request.getVehicleNumber());

        Booking booking = new Booking();
        booking.setSlotId(slot.getSlotId());
        booking.setUserId(request.getUserId());
        booking.setVehicleNumber(request.getVehicleNumber());
        booking.setBookingTime(LocalDateTime.now());

        return bookingRepository.save(booking);
    }
}

