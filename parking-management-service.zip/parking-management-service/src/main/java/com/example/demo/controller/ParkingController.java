package com.example.demo.controller;

import com.example.demo.model.ParkingSlot;
import com.example.demo.service.ParkingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/parking")
public class ParkingController {

    @Autowired
    private ParkingService parkingService;

    @PostMapping("/create")
    public ResponseEntity<String> createSlots(@RequestParam int count) {
        return ResponseEntity.ok(parkingService.createSlots(count));
    }

    @GetMapping("/available")
    public ResponseEntity<?> getAvailableSlot() {
        Optional<ParkingSlot> slot = parkingService.getAvailableSlot();
        return slot.<ResponseEntity<?>>map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.ok("No slots available"));
    }

    @GetMapping("/all")
    public ResponseEntity<List<ParkingSlot>> getAllSlots() {
        return ResponseEntity.ok(parkingService.getAllSlots());
    }
}